

/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_occurrenceActive]    Script Date: 03/11/2014 15:14:11 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_get_occurrenceActive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_get_occurrenceActive]
GO



/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_occurrenceActive]    Script Date: 03/11/2014 15:14:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--             UPDATES                          
-- 2/15/2011 - Chris Funk  - Added Attendance Type Sort Order (ot.type_order) to result set.
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_get_occurrenceActive]
	-- Add the parameters for the stored procedure here
	@lookup_type_id INT = 0 ,
	@OrganizationID INT = 1 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
SELECT 	
	O.occurrence_id,
	O.location,
	O.occurrence_closed,
	O.check_in_start,
	O.check_in_end,
	O.occurrence_type,
	O.occurrence_name,
	O.occurrence_start_time,
	O.occurrence_end_time,
	Ot.type_name,	
	Ot.min_leaders,
	Ot.people_per_leader,
	Ot.use_room_ratios,
	ot.type_order,
	Otg.group_id,
	Otg.group_name,
	l.max_people,
	l.location_id,
	l.include_leaders_for_max_people,
	l.room_closed,
	(SELECT COUNT(*) 
		FROM core_occurrence_attendance WITH(NOLOCK)
		WHERE occurrence_id = O.occurrence_id
		AND attended = 1 AND check_in_time >= O.check_in_start AND check_out_time = '1/1/1900' AND [type] = 1) AS current_attendees,
	(SELECT COUNT(*) FROM core_occurrence_attendance WITH(NOLOCK)
		WHERE occurrence_id = O.occurrence_id
		AND attended = 1 AND check_in_time >= O.check_in_start AND check_out_time = '1/1/1900' AND [type] = 2) AS current_volunteers,
	cast(otr.occurrence_type_ratio_value as int) as occurrence_type_ratio_value

FROM core_occurrence O WITH(NOLOCK)
INNER JOIN core_occurrence_type Ot WITH(NOLOCK) ON Ot.occurrence_type_id = O.occurrence_type AND Ot.organization_id = O.organization_id
INNER JOIN core_occurrence_type_group Otg WITH(NOLOCK) ON Ot.group_id = Otg.group_id  AND Ot.organization_id = Otg.organization_id
INNER JOIN orgn_location l WITH(NOLOCK) ON l.location_id = O.location_id AND l.organization_id = O.organization_id
LEFT OUTER JOIN (SELECT lookup_value as occurrence_type, lookup_qualifier AS occurrence_type_ratio_value
			FROM core_lookup WITH(NOLOCK)
			WHERE lookup_type_id = @lookup_type_id AND organization_id = @OrganizationID AND active = 1) otr on cast(Ot.occurrence_type_id as varchar) = otr.occurrence_type
WHERE O.organization_id = @OrganizationID
AND O.check_in_start <> '1/1/1900'
AND O.check_in_start <= GETDATE()
AND O.check_in_end >= GETDATE()
ORDER BY O.occurrence_name


END



GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_occurrence_attendanceByOccurrenceID]    Script Date: 03/11/2014 15:14:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_get_occurrence_attendanceByOccurrenceID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_get_occurrence_attendanceByOccurrenceID]
GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_occurrence_attendanceByOccurrenceID]    Script Date: 03/11/2014 15:14:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROC [dbo].[cust_SECC_checkin_sp_get_occurrence_attendanceByOccurrenceID]
@OccurrenceID int,
@AttendanceStatus int,
@OrganizationID INT = 1 

AS

IF @AttendanceStatus = 1 
BEGIN

	SELECT	
		ISNULL(a.occurrence_attendance_id,-1) as occurrence_attendance_id,
		a.security_code,
		a.check_in_time,
		a.check_out_time,
		a.occurrence_id,
		a.person_id,
		a.session_id,
		a.type,
		p.guid AS person_guid,
		FM.family_id,
		p.last_name,
		p.nick_name,
		p.first_name,
		P.nick_name + ' ' + p.last_name as person_name,
		RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
		CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
			 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
		WHEN 0 THEN 'Active'
		WHEN 1 THEN 'Inactive'
		WHEN 2 THEN 'Pending'
		ELSE '-' END AS record_status,
		p.birth_date,
		BP.list_business_phone,
		MP.list_cell_phone,
		ADR.address_id,
		ADR.street_address_1 +
		CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
			CHAR(10) + CHAR(13) + ADR.street_address_2
		ELSE '' END AS Address,
		ADR.city,
		ADR.state,
		ADR.postal_code,
		ADR.country,
		a.attended,
		a.notes,
		a.pager,
		p.medical_information,
		(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid,
		p.guid,
		syst.system_name,
		syst.system_id
	FROM core_occurrence_attendance a WITH(NOLOCK)
	LEFT OUTER JOIN chkn_session sess WITH(NOLOCK) ON a.session_id = sess.session_id and sess.organization_id = @OrganizationID
	LEFT OUTER JOIN comp_system syst WITH(NOLOCK) ON sess.system_id = syst.system_id and sess.organization_id = syst.organization_id
	LEFT OUTER JOIN core_person p WITH(NOLOCK) ON p.person_id = a.person_id and p.organization_id = @OrganizationID
	LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
	LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id AND PA.primary_address = 1 and PA.organization_id = p.organization_id
	LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
	LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
	LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
	WHERE  occurrence_id = @OccurrenceID
	AND attended = 1
	ORDER BY last_name, first_name

END
ELSE
BEGIN

	IF @AttendanceStatus = -1
	BEGIN
	
		SELECT
			ISNULL(oa.occurrence_attendance_id,-1) as occurrence_attendance_id,
			oa.security_code,
			oa.check_in_time,
			oa.check_out_time,
			o.occurrence_id,
			pm.person_id,
			oa.session_id,
			oa.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
			CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
				 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			p.birth_date,
			BP.list_business_phone,
			MP.list_cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			CASE WHEN oa.attended is null THEN CAST(0 as bit) ELSE oa.attended END AS attended,
			CASE WHEN oa.notes is null THEN '' ELSE oa.notes END AS notes,
			CASE WHEN oa.pager is null THEN '' ELSE oa.pager END AS pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid
		FROM core_occurrence o WITH(NOLOCK)
		INNER JOIN core_profile_occurrence po WITH(NOLOCK) on o.occurrence_id = po.occurrence_id
		INNER JOIN core_profile_member pm WITH(NOLOCK) on pm.profile_id = po.profile_id and pm.organization_id = @OrganizationID
		INNER JOIN core_lookup slu WITH(NOLOCK) on slu.lookup_id = pm.status_luid and slu.organization_id = pm.organization_id
		INNER JOIN core_person p WITH(NOLOCK) on p.person_id = pm.person_id and p.organization_id = pm.organization_id
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id AND PA.organization_id = p.organization_id AND PA.primary_address = 1 
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_occurrence_attendance oa WITH(NOLOCK) on oa.occurrence_id = o.occurrence_id
			and oa.person_id = pm.person_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
		WHERE o.occurrence_id = @OccurrenceID
			AND o.organization_id = @OrganizationID
		AND slu.lookup_qualifier IN ('P','A')
		
		UNION
		
		SELECT
			ISNULL(oa.occurrence_attendance_id,-1) as occurrence_attendance_id,
			oa.security_code,
			oa.check_in_time,
			oa.check_out_time,
			o.occurrence_id,
			p.person_id,
			oa.session_id,
			oa.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
			CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
				 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			p.birth_date,
			BP.list_business_phone,
			MP.cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			CASE WHEN oa.attended is null THEN CAST(0 as bit) ELSE oa.attended END AS attended,
			CASE WHEN oa.notes is null THEN '' ELSE oa.notes END AS notes,
			CASE WHEN oa.pager is null THEN '' ELSE oa.pager END AS pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid
		FROM core_occurrence o WITH(NOLOCK)
		INNER JOIN smgp_group_occurrence po WITH(NOLOCK) on o.occurrence_id = po.occurrence_id
		INNER JOIN smgp_group g WITH(NOLOCK) on g.group_id = po.group_id and g.organization_id = @OrganizationID
		INNER JOIN core_person p WITH(NOLOCK) on p.person_id = g.leader_person_id and p.organization_id = g.organization_id
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id AND PA.organization_id = p.organization_id AND PA.primary_address = 1
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_occurrence_attendance oa WITH(NOLOCK) ON oa.occurrence_id = o.occurrence_id
			and oa.person_id = p.person_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
		WHERE o.occurrence_id = @OccurrenceID
			and o.organization_id = @OrganizationID
		
		UNION

		SELECT
			ISNULL(oa.occurrence_attendance_id,-1) as occurrence_attendance_id,
			oa.security_code,
			oa.check_in_time,
			oa.check_out_time,
			o.occurrence_id,
			pm.person_id,
			oa.session_id,
			oa.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
			CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
				 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			p.birth_date,
			BP.list_business_phone,
			MP.cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			CASE WHEN oa.attended is null THEN CAST(0 as bit) ELSE oa.attended END AS attended,
			CASE WHEN oa.notes is null THEN '' ELSE oa.notes END AS notes,
			CASE WHEN oa.pager is null THEN '' ELSE oa.pager END AS pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OccurrenceID) AS photo_guid
		FROM core_occurrence o WITH(NOLOCK)
		INNER JOIN smgp_group_occurrence po WITH(NOLOCK) on o.occurrence_id = po.occurrence_id 
		INNER JOIN smgp_member pm WITH(NOLOCK) on pm.group_id = po.group_id and pm.organization_id = @OrganizationID
		INNER JOIN core_person p WITH(NOLOCK) on p.person_id = pm.person_id and p.organization_id = pm.organization_id
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id and PA.organization_id = p.organization_id AND PA.primary_address = 1
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_occurrence_attendance oa WITH(NOLOCK) on oa.occurrence_id = o.occurrence_id
			and oa.person_id = pm.person_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
		WHERE o.occurrence_id = @OccurrenceID
			and o.organization_id = @OrganizationID
		
		UNION
		
		SELECT
			ISNULL(a.occurrence_attendance_id,-1) as occurrence_attendance_id,
			a.security_code,
			a.check_in_time,
			a.check_out_time,
			a.occurrence_id,
			a.person_id,
			a.session_id,
			a.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
			CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
				 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			p.birth_date,
			BP.list_business_phone,
			MP.cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			a.attended,
			a.notes,
			a.pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid
		FROM core_occurrence_attendance a WITH(NOLOCK)
		LEFT OUTER JOIN core_person p WITH(NOLOCK) on p.person_id = a.person_id and p.organization_id = @OrganizationID
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id and PA.organization_id = p.organization_id AND PA.primary_address = 1
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
		WHERE occurrence_id = @OccurrenceID
	
		ORDER BY last_name, first_name

	END
	ELSE
	BEGIN

		SELECT	
			ISNULL(oa.occurrence_attendance_id,-1) as occurrence_attendance_id,
			oa.security_code,
			oa.check_in_time,
			oa.check_out_time,
			o.occurrence_id,
			pm.person_id,
			oa.session_id,
			oa.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
			CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
				 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			p.birth_date,
			BP.list_business_phone,
			MP.cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			CASE WHEN oa.attended is null THEN CAST(0 as bit) ELSE oa.attended END AS attended,
			CASE WHEN oa.notes is null THEN '' ELSE oa.notes END AS notes,
			CASE WHEN oa.pager is null THEN '' ELSE oa.pager END AS pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid
		FROM core_occurrence o WITH(NOLOCK)
		INNER JOIN core_profile_occurrence po WITH(NOLOCK) on o.occurrence_id = po.occurrence_id
		INNER JOIN core_profile_member pm WITH(NOLOCK) on pm.profile_id = po.profile_id and pm.organization_id = @OrganizationID
		INNER JOIN core_lookup slu WITH(NOLOCK) on slu.lookup_id = pm.status_luid and slu.organization_id = pm.organization_id
		INNER JOIN core_person p WITH(NOLOCK) on p.person_id = pm.person_id and p.organization_id = pm.organization_id
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id AND PA.organization_id = p.organization_id AND PA.primary_address = 1
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_occurrence_attendance oa WITH(NOLOCK) ON oa.occurrence_id = o.occurrence_id
			and oa.person_id = pm.person_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
		WHERE o.occurrence_id = @OccurrenceID
			and o.organization_id = @OrganizationID
		AND (oa.attended IS NULL OR oa.attended = 0)
		AND slu.lookup_qualifier in ('P', 'A')
		
		UNION
		
		SELECT	
			ISNULL(oa.occurrence_attendance_id,-1) as occurrence_attendance_id,
			oa.security_code,
			oa.check_in_time,
			oa.check_out_time,
			o.occurrence_id,
			pm.person_id,
			oa.session_id,
			oa.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
			CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
				 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			p.birth_date,
			BP.list_business_phone,
			MP.cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			CASE WHEN oa.attended is null THEN CAST(0 as bit) ELSE oa.attended END AS attended,
			CASE WHEN oa.notes is null THEN '' ELSE oa.notes END AS notes,
			CASE WHEN oa.pager is null THEN '' ELSE oa.pager END AS pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID ) AS photo_guid
		FROM core_occurrence o WITH(NOLOCK)
		INNER JOIN smgp_group_occurrence po WITH(NOLOCK) on o.occurrence_id = po.occurrence_id
		INNER JOIN smgp_member pm WITH(NOLOCK) on pm.group_id = po.group_id and pm.organization_id = @OrganizationID
		INNER JOIN core_person p WITH(NOLOCK) on p.person_id = pm.person_id and p.organization_id = pm.organization_id
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id AND PA.organization_id = p.organization_id AND PA.primary_address = 1
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_occurrence_attendance oa WITH(NOLOCK) on oa.occurrence_id = o.occurrence_id
			and oa.person_id = pm.person_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id
		WHERE o.occurrence_id = @OccurrenceID
			and o.organization_id = @OrganizationID
		AND (oa.attended IS NULL OR oa.attended = 0)
	

		UNION
		
		SELECT	
			ISNULL(a.occurrence_attendance_id,-1) as occurrence_attendance_id,
			a.security_code,
			a.check_in_time,
			a.check_out_time,
			a.occurrence_id,
			a.person_id,
			a.session_id,
			a.type,
			p.guid AS person_guid,
			FM.family_id,
			p.last_name,
			p.nick_name,
			p.first_name,
			P.nick_name + ' ' + p.last_name as person_name,
			p.last_name + ', ' + p.nick_name as full_name,
			CASE p.record_status
			WHEN 0 THEN 'Active'
			WHEN 1 THEN 'Inactive'
			WHEN 2 THEN 'Pending'
			ELSE '-' END AS record_status,
			BP.list_business_phone,
			MP.cell_phone,
			ADR.address_id,
			ADR.street_address_1 +
			CASE WHEN ADR.street_address_2 IS NOT NULL AND ADR.street_address_2 <> '' THEN
				CHAR(10) + CHAR(13) + ADR.street_address_2
			ELSE '' END AS Address,
			p.birth_date,
			ADR.city,
			ADR.state,
			ADR.postal_code,
			ADR.country,
			a.attended,
			a.notes,
			a.pager,
			p.medical_information,
			(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid
		FROM core_occurrence_attendance a WITH(NOLOCK)
		INNER JOIN core_person p WITH(NOLOCK) on p.person_id = a.person_id and p.organization_id = @OrganizationID
		LEFT OUTER JOIN core_family_member FM WITH(NOLOCK) ON FM.person_id = P.person_id and FM.organization_id = p.organization_id
		LEFT OUTER JOIN core_person_address PA WITH(NOLOCK) ON PA.person_id = P.person_id AND PA.organization_id = p.organization_id AND PA.primary_address = 1
		LEFT OUTER JOIN core_address ADR WITH(NOLOCK) ON ADR.address_id = PA.address_id and ADR.organization_id = PA.organization_id
		LEFT OUTER JOIN core_v_phone_business BP WITH(NOLOCK) ON p.person_id = BP.person_id
		LEFT OUTER JOIN core_v_phone_cell MP WITH(NOLOCK) ON p.person_id = MP.person_id

		WHERE occurrence_id = @OccurrenceID
		AND attended = 0

		ORDER BY last_name, first_name

	END
		
END


GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_occurrenceAttendees]    Script Date: 03/11/2014 15:15:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_get_occurrenceAttendees]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_get_occurrenceAttendees]
GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_occurrenceAttendees]    Script Date: 03/11/2014 15:15:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_get_occurrenceAttendees]
	@Organization_ID INT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT	
		ISNULL(a.occurrence_attendance_id,-1) as occurrence_attendance_id,
		a.security_code,
		a.check_in_time,
		a.check_out_time,
		a.occurrence_id,
		a.person_id,
		a.session_id,
		a.type,
		p.guid AS person_guid,
		p.last_name,
		p.nick_name,
		p.first_name,
		P.nick_name + ' ' + p.last_name as person_name,
		RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
		CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
			 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
		WHEN 0 THEN 'Active'
		WHEN 1 THEN 'Inactive'
		WHEN 2 THEN 'Pending'
		ELSE '-' END AS record_status,
		p.birth_date,
		a.attended,
		a.notes,
		a.pager,
		p.medical_information,
		(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @Organization_ID) AS photo_guid,
		p.guid,
		O.occurrence_name,
		O.occurrence_type,
		Ot.[type_name],
		l.location_name,
		syst.system_name,
		syst.system_id
	FROM core_occurrence_attendance a WITH(NOLOCK)
	INNER JOIN core_occurrence O WITH(NOLOCK) on a.occurrence_id = O.occurrence_id and O.organization_id = @Organization_ID
	INNER JOIN core_occurrence_type Ot WITH(NOLOCK) ON Ot.occurrence_type_id = O.occurrence_type and Ot.organization_id = O.organization_id
	INNER JOIN core_occurrence_type_group Otg WITH(NOLOCK) ON Ot.group_id = Otg.group_id and Ot.organization_id = Otg.organization_id
	INNER JOIN orgn_location l WITH(NOLOCK) ON l.location_id = O.location_id and l.organization_id = O.organization_id
	LEFT OUTER JOIN core_person p WITH(NOLOCK) on p.person_id = a.person_id and p.organization_id = @Organization_ID
	LEFT OUTER JOIN chkn_session sess WITH(NOLOCK) ON a.session_id = sess.session_id AND sess.organization_id = @Organization_ID
	LEFT OUTER JOIN comp_system syst WITH(NOLOCK) ON sess.system_id = syst.system_id and sess.organization_id = syst.organization_id
	WHERE O.check_in_start <> '1/1/1900'
		AND O.check_in_start <= GETDATE()
		AND O.check_in_end >= GETDATE()
	AND attended = 1
	ORDER BY last_name, first_name
END


GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_searchActiveAttendees]    Script Date: 03/11/2014 15:15:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_get_searchActiveAttendees]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_get_searchActiveAttendees]
GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_searchActiveAttendees]    Script Date: 03/11/2014 15:15:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_get_searchActiveAttendees]
	-- Add the parameters for the stored procedure here
	@name1 nvarchar(40) = NULL,
	@name2 nvarchar(40) = NULL,
	@securityCode varchar(6) = NULL,
	@OrganizationID INT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT	
		ISNULL(a.occurrence_attendance_id,-1) as occurrence_attendance_id,
		a.security_code,
		a.check_in_time,
		a.check_out_time,
		a.occurrence_id,
		a.person_id,
		a.session_id,
		a.type,
		p.guid AS person_guid,
		p.last_name,
		p.nick_name,
		p.first_name,
		P.nick_name + ' ' + p.last_name as person_name,
		RTRIM(RTRIM(ISNULL(P.last_name,'')) + ', ' + 
		CASE WHEN LEN(RTRIM(ISNULL(P.nick_name,''))) = 0 THEN RTRIM(ISNULL(P.first_name,''))
			 ELSE RTRIM(ISNULL(P.nick_name,'')) END) AS full_name,
			CASE p.record_status
		WHEN 0 THEN 'Active'
		WHEN 1 THEN 'Inactive'
		WHEN 2 THEN 'Pending'
		ELSE '-' END AS record_status,
		p.birth_date,
		a.attended,
		a.notes,
		a.pager,
		p.medical_information,
		(SELECT ISNULL(CAST(guid as varchar(80)),'') FROM util_blob where blob_id = P.blob_id and organization_id = @OrganizationID) AS photo_guid,
		p.guid,
		O.occurrence_name,
		O.occurrence_type,
		Ot.[type_name],
		l.location_name as location,
		syst.system_name,
		syst.system_id
	FROM core_occurrence_attendance a WITH(NOLOCK)
	INNER JOIN core_occurrence O WITH(NOLOCK) on a.occurrence_id = O.occurrence_id and O.organization_id = @OrganizationID
	INNER JOIN core_occurrence_type Ot WITH(NOLOCK) ON Ot.occurrence_type_id = O.occurrence_type and Ot.organization_id = O.organization_id
	INNER JOIN core_occurrence_type_group Otg WITH(NOLOCK) ON Ot.group_id = Otg.group_id and Ot.organization_id = Otg.organization_id
	INNER JOIN orgn_location l WITH(NOLOCK) ON l.location_id = O.location_id and l.organization_id = O.organization_id
	INNER JOIN core_person p WITH(NOLOCK) ON p.person_id = a.person_id and p.organization_id = @OrganizationID
	LEFT OUTER JOIN chkn_session sess WITH(NOLOCK) ON a.session_id = sess.session_id AND sess.organization_id = @OrganizationID
	LEFT OUTER JOIN comp_system syst WITH(NOLOCK) ON sess.system_id = syst.system_id and sess.organization_id = syst.organization_id
	WHERE a.check_in_time >= DATEADD(dd, DATEDIFF(dd,0,GETDATE()), 0) 
	AND (attended = 1)
	AND (
		((p.first_name LIKE '%' + @name1 + '%' OR p.nick_name LIKE '%' + @name1 + '%') AND p.last_name LIKE '%' + @name2 + '%') OR
		((p.first_name LIKE '%' + @name2 + '%' OR p.nick_name LIKE '%' + @name2 + '%') AND p.last_name LIKE '%' + @name1 + '%') OR
		((p.first_name LIKE '%' + @name1 + '%' OR p.nick_name LIKE '%' + @name1 + '%') AND @name2 IS NULL) OR
		(p.last_name LIKE '%' + @name1 + '%' AND @name2 IS NULL) OR
		(a.security_code LIKE '%' + @securityCode + '%')) 
	ORDER BY last_name, first_name

END


GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_familyoccurrences]    Script Date: 03/11/2014 15:16:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_get_familyoccurrences]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_get_familyoccurrences]
GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_familyoccurrences]    Script Date: 03/11/2014 15:16:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_get_familyoccurrences]
	@OccurrenceAttendanceID int,
	@OrganizationID INT = 1
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @familyid int 
	set @familyid = (select cfm.family_id from core_occurrence_attendance coa inner join core_family_member cfm on coa.person_id = cfm.person_id where coa.occurrence_attendance_id = @OccurrenceAttendanceID AND cfm.organization_id = @OrganizationID)

	SELECT coa.occurrence_attendance_id, 		
		RTRIM(RTRIM(ISNULL(cp.last_name,'')) + ', ' + 
		CASE WHEN LEN(RTRIM(ISNULL(cp.nick_name,''))) = 0 THEN RTRIM(ISNULL(cp.first_name,''))
			 ELSE RTRIM(ISNULL(cp.nick_name,'')) END) AS full_name, 
		co.location,
		co.occurrence_type 
	from core_occurrence_attendance coa WITH(NOLOCK)
	inner join core_occurrence co WITH(NOLOCK) on coa.occurrence_id = co.occurrence_id and co.organization_id = @OrganizationID
	inner join core_person cp WITH(NOLOCK) on coa.person_id = cp.person_id and cp.organization_id = @OrganizationID
	inner join core_family_member cfm WITH(NOLOCK) on cfm.person_id = coa.person_id and cfm.organization_id = @OrganizationID
	where cfm.family_id = @familyid AND coa.attended = 1  
	AND co.occurrence_start_time between CONVERT (date, GETDATE()) AND DATEADD(DAY, 1, CONVERT (date, GETDATE()))
	--(co.occurrence_start_time >= CONVERT (date, GETDATE()) OR co.check_in_start >= CONVERT (date, GETDATE()))
END


GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_panic]    Script Date: 03/11/2014 15:16:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_get_panic]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_get_panic]
GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_get_panic]    Script Date: 03/11/2014 15:16:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_get_panic]
	-- Add the parameters for the stored procedure here
	@panicProfileID as int,
	@panicMode as bit output, 
	@OrganizationID as INT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
	SET @panicMode = (CASE WHEN (
		SELECT COUNT(*) 
		FROM core_profile_member WITH(NOLOCK) 
		WHERE profile_id=@panicProfileID and organization_id = @OrganizationID AND status_luid = 255) > 0 THEN 1 ELSE 0 END)
		
END


GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_panic]    Script Date: 03/11/2014 15:17:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_panic]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_panic]
GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_panic]    Script Date: 03/11/2014 15:17:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[cust_SECC_checkin_sp_panic]
	@enable as bit,
	@profileID as int,
	@OrganizationID as int = 1
AS
BEGIN
	IF @enable = 1
		BEGIN
			UPDATE core_profile_member
			SET status_luid=255
			WHERE profile_id=@profileID
				and organization_id = @OrganizationID
		END
	ELSE
		BEGIN
			UPDATE core_profile_member
			SET status_luid=316
			WHERE profile_id=@profileID
				and organization_id = @OrganizationID
		END
END


GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_setroomratios]    Script Date: 03/11/2014 15:17:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_setroomratios]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_setroomratios]
GO

/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_setroomratios]    Script Date: 03/11/2014 15:17:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[cust_SECC_checkin_sp_setroomratios]
	@attendanceTypeId as int,
	@minLeaders as int,
	@peoplePerLeader as int,
	@Organization_ID INT = 1
AS
BEGIN

	
	UPDATE core_occurrence_type
	SET min_leaders = @minLeaders,
		people_per_leader = @peoplePerLeader
	WHERE occurrence_type_id = @attendanceTypeId 
		AND organization_id = @Organization_ID
		
	
END


GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_save_occurrence_status]    Script Date: 03/11/2014 15:18:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_save_occurrence_status]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_save_occurrence_status]
GO



/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_save_occurrence_status]    Script Date: 03/11/2014 15:18:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_save_occurrence_status]
	@OccurrenceID int,
	@UserId varchar(50),
	@OccurrenceClosed bit,
	@OrganizationID INT = 1
AS
BEGIN
	UPDATE core_occurrence Set
		[date_modified] = GETDATE(), 
		[modified_by] = @UserID, 
		[occurrence_closed] = @OccurrenceClosed
	WHERE
		occurrence_id = @OccurrenceID
		AND organization_id = @OrganizationID
END


GO



/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_save_occurrenceActive]    Script Date: 03/11/2014 15:18:35 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cust_SECC_checkin_sp_save_occurrenceActive]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cust_SECC_checkin_sp_save_occurrenceActive]
GO


/****** Object:  StoredProcedure [dbo].[cust_SECC_checkin_sp_save_occurrenceActive]    Script Date: 03/11/2014 15:18:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[cust_SECC_checkin_sp_save_occurrenceActive]
	@UserId varchar(50),
	@OccurrenceClosed bit,
	@FilteredOccurrences varchar(8000) = '',
	@OrganizationID INT = 1
AS
BEGIN

IF LEN(@FilteredOccurrences) = 0 
	BEGIN
		UPDATE core_occurrence Set
			[date_modified] = GETDATE(), 
			[modified_by] = @UserID, 
			[occurrence_closed] = @OccurrenceClosed
		WHERE organization_id = @OrganizationID
			AND [check_in_start] <> '1/1/1900'
			AND [check_in_start] <= GETDATE()
			AND [check_in_end] >= GETDATE()
	END
ELSE
	BEGIN
		UPDATE core_occurrence Set
			[date_modified] = GETDATE(), 
			[modified_by] = @UserID, 
			[occurrence_closed] = @OccurrenceClosed
		WHERE organization_id = @OrganizationID
			AND [check_in_start] <> '1/1/1900'
			AND [check_in_start] <= GETDATE()
			AND [check_in_end] >= GETDATE()
			AND occurrence_type IN 
				(
					SELECT occurrence_type_id
					FROM core_occurrence_type 
					WHERE organization_id = @OrganizationID AND  group_id in (SELECT CAST(ITEM AS INT) from dbo.fnSplit(@FilteredOccurrences))
				)		
	END

END


GO

